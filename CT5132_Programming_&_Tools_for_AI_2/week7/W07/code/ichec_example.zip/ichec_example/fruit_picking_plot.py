import sys
import numpy as np
import matplotlib.pyplot as plt


def plot(x, i):
    # make a plot to show T, w and x
    plt.xlim((0, 1))
    plt.ylim((0, 1))
    # plot the tree locations and use size to indicate amount of fruit w
    plt.scatter(T[:, 0], T[:, 1], s=100.0*w*w, c="g")
    bins = x.reshape((-1, 2))
    # plot the bin locations as squares
    plt.scatter(bins[:, 0], bins[:, 1], marker="s", c="r")
    plt.axes().set_aspect('equal')
    plt.savefig("fruit_picking_%s.png" % str(i).zfill(5))
    plt.close()


tree_data_filename = sys.argv[1]
solutions_filename = sys.argv[2]
data = np.genfromtxt(tree_data_filename)
T = data[:, 0:2] # x, y locations of trees
w = data[:, 2] # amount of fruit per tree
n = T.shape[0]
history = np.loadtxt(solutions_filename)

for i, x in enumerate(history):
    plot(x, i)

