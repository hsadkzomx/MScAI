python fruit_picking.py fruit_picking.dat 5 1 > output_5_1.dat # each line must be a shell command
python fruit_picking.py fruit_picking.dat 5 2 > output_5_2.dat # don't write any comment lines
python fruit_picking.py fruit_picking.dat 10 1 > output_10_1.dat # we can use a script to generate this file if it is too large to write by hand
python fruit_picking.py fruit_picking.dat 10 2 > output_10_2.dat # notice we use ">" to capture the python terminal output in a .dat file
